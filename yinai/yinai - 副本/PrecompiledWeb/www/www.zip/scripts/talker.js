﻿function product_list_talker()
{
    
}